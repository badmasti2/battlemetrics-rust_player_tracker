# Changelog

## v9.0
- **Fixed:** status detection now reads the live "Active Players" table
  instead of the scrolling join/leave event feed. On busy servers, the event
  feed can cycle through its ~25 visible entries in just a few minutes,
  causing the previous approach to silently miss short-lived join/leave
  events. Reading the active roster directly removes this race condition
  entirely.

## v8.1
- **Fixed:** manual status overrides (the 🟢/🔴/🟠 buttons) now route through
  the same status-change function as live detection, so they correctly
  trigger notifications and keep internal state in sync. Previously, manual
  changes could silently desync the tracker's internal "last known status,"
  causing incorrect or missing notifications afterward.
- Notifications now show both the old and new status (e.g. "Steve is now
  Offline (was Online)") instead of a generic "status has changed" message.
- Newly added players start in the "Unknown" state without triggering a
  notification.

## v8.0
- Initial tracked version: per-player online/offline/unknown tracking,
  desktop notifications on detected changes, manual override buttons, and
  an on-page status panel.
