// ==UserScript==
// @name         BattleMetrics Rust Player Tracker
// @namespace    battlemetrics-rust-tracker
// @version      9.0
// @description  Track specific Rust players on BattleMetrics and get a desktop notification whenever their online/offline/unknown status changes.
// @match        https://www.battlemetrics.com/servers/rust/*
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-idle
// ==/UserScript==

(function(){

"use strict";

let players = GM_getValue("players", []);
let status = GM_getValue("status", {});
let manual = GM_getValue("manual", {});
let lastStatus = GM_getValue("lastStatus", {});

let firstScan = true;


if(Notification.permission !== "granted")
    Notification.requestPermission();



function save(){

    GM_setValue("players",players);
    GM_setValue("status",status);
    GM_setValue("manual",manual);
    GM_setValue("lastStatus",lastStatus);

}



// Turns true/false/null/undefined into a readable label
function label(value){

    if(value === true)
        return "Online";

    if(value === false)
        return "Offline";

    return "Unknown";

}



function notify(name, oldValue, newValue){

    if(Notification.permission !== "granted")
        return;


    new Notification(
        "Player Status Changed",
        {
            body: name + " is now " + label(newValue) + " (was " + label(oldValue) + ")"
        }
    );

}



// Single choke point for changing a player's status.
// Handles online<->offline<->unknown in any direction,
// notifies on any real change, and keeps status/lastStatus in sync.
function setStatus(name, newValue, opts){

    opts = opts || {};

    let oldValue = lastStatus.hasOwnProperty(name) ? lastStatus[name] : undefined;

    // normalize so unknown is always represented the same way (null)
    if(newValue === undefined)
        newValue = null;


    let changed = oldValue !== newValue;


    status[name] = newValue;
    lastStatus[name] = newValue;


    if(changed && !firstScan && !opts.silent){

        notify(name, oldValue, newValue);

    }


    return changed;

}



// Reads the "Active players" table, which lists everyone currently
// online on the server right now. This is a live roster snapshot,
// not a scrolling event log, so there's no risk of missing a
// join/leave line that only appears briefly in a fast-moving feed.
function getActivePlayerNames(){

    let table=document.querySelector('[data-testid="active-players"]');

    if(!table)
        return null;


    let names=[];

    table.querySelectorAll("tbody tr").forEach(row=>{

        let link=row.querySelector("td a");

        if(link){
            names.push(link.textContent.trim());
        }

    });


    return names;

}



function checkPlayers(){

    let activeNames=getActivePlayerNames();


    // If the table isn't found (page structure changed, still
    // loading, wrong page, etc), skip this cycle entirely rather
    // than assuming everyone is offline.
    if(activeNames===null){
        return;
    }


    let activeLower=activeNames.map(n=>n.toLowerCase());


    players.forEach(name=>{


        let isOnline=activeLower.includes(name.toLowerCase());


        setStatus(name, isOnline);


    });



    save();

    update();


    firstScan=false;

}function update(){

    let box=document.getElementById("rtPlayers");

    if(!box)
        return;


    box.innerHTML="";


    players.forEach(name=>{


        let icon="🟠";


        if(status[name]===true)
            icon="🟢";


        if(status[name]===false)
            icon="🔴";



        box.innerHTML+=`

        <div>
        ${icon} ${name}
        </div>

        `;


    });

}





function createUI(){

    if(document.getElementById("rustTracker"))
        return;



    let ui=document.createElement("div");


    ui.id="rustTracker";


    ui.innerHTML=`

    <div class="rtTitle">
    Rust Player Tracker
    </div>


    <div id="rtServer">
    Loading...
    </div>



    <div class="rtSection">

    <b>Track Player</b><br>


    <input id="rtInput" placeholder="Username">


    <button id="add">
    Add
    </button>


    <button id="remove">
    Remove
    </button>



    <div class="rtButtons">

    <button id="online">
    🟢 Online
    </button>


    <button id="offline">
    🔴 Offline
    </button>


    <button id="unknown">
    🟠 Unknown
    </button>


    </div>


    </div>



    <div class="rtSection">

    <b>Players Currently Tracking</b>

    <div id="rtPlayers"></div>


    </div>


    `;



    document.body.appendChild(ui);



    let css=document.createElement("style");


    css.textContent=`

    #rustTracker{

    position:fixed;
    right:20px;
    top:108px;
    width:340px;
    background:#222222;
    color:white;
    padding:12px;
    z-index:999999;
    font-family:Arial;
    font-size:13px;

    }


    .rtTitle{

    font-size:16px;
    font-weight:bold;
    margin-bottom:10px;

    }


    .rtSection{

    margin-top:15px;

    }


    #rtInput{

    background:#111;
    color:white;
    border:0;
    padding:6px;
    width:145px;

    }


    button{

    background:#333;
    color:white;
    border:0;
    padding:5px;

    }


    .rtButtons{

    display:flex;
    gap:3px;
    margin-top:5px;

    }


    .rtButtons button{

    flex:1;
    font-size:11px;

    }

    `;


    document.head.appendChild(css);





    document.getElementById("add").onclick=()=>{


        let n=document
        .getElementById("rtInput")
        .value
        .trim();



        if(n && !players.includes(n)){


            players.push(n);

            // new player starts as unknown, no notification for this
            setStatus(n, null, {silent:true});


            save();

            update();


        }


    };





    document.getElementById("remove").onclick=()=>{


        let n=document
        .getElementById("rtInput")
        .value
        .trim()
        .toLowerCase();



        players=players.filter(
            p=>p.toLowerCase()!=n
        );


        delete status[n];
        delete manual[n];
        delete lastStatus[n];


        save();

        update();


    };





    document.getElementById("online").onclick=()=>setManual(true);


    document.getElementById("offline").onclick=()=>setManual(false);





    document.getElementById("unknown").onclick=()=>{


        let n=document
        .getElementById("rtInput")
        .value
        .trim();



        if(!n)
            return;


        delete manual[n];


        // route through setStatus so lastStatus stays in sync
        // and this counts as a real, notifiable transition
        setStatus(n, null);


        save();

        update();


    };






    function setManual(value){


        let n=document
        .getElementById("rtInput")
        .value
        .trim();



        if(n){


            manual[n]=value;


            // route through setStatus so lastStatus stays in sync
            // and this counts as a real, notifiable transition
            setStatus(n, value);


            save();

            update();


        }


    }


}







function updateServer(){

    let box=document.getElementById("rtServer");


    if(!box)
        return;



    let title=document.querySelector("h1");


    let count=document.body.innerText.match(
        /Player count\s+(\d+\/\d+)/
    );



    box.innerHTML=

    (title ? title.innerText : "Rust Server")
    +
    "<br>🟢 Online "
    +
    (
        count
        ?
        "👥 "+count[1]
        :
        ""
    );

}







createUI();


setInterval(
    checkPlayers,
    2000
);


setInterval(
    updateServer,
    3000
);



})();
