@echo off
setlocal

:: ============================================================
:: Fix: Windows Notifications Suppressed During Fullscreen Games
:: ============================================================
:: This disables Focus Assist's automatic "When I'm playing a
:: game" rule, which normally silences all notifications
:: (including Chrome/Tampermonkey ones) while a fullscreen game
:: like Rust has focus.
::
:: Must be run as Administrator.
:: ============================================================

net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo.
    echo ERROR: This script must be run as Administrator.
    echo Right-click this file and choose "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo.
echo Disabling Focus Assist automatic rule for fullscreen apps/games...
echo.

:: Turns off the "When I'm playing a game" automatic Focus Assist rule
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount\Current\windows.data.notifications.quiethourssettings" /v Data /t REG_BINARY /d 00 /f >nul 2>&1

:: Disables automatic rules tied to fullscreen detection
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v NOC_GLOBAL_SETTING_TOASTS_ENABLED /t REG_DWORD /d 1 /f >nul 2>&1

:: Ensures Focus Assist automatic rules for "playing a game" and
:: "fullscreen apps" are turned off (0 = off, 2 = on)
powershell -NoProfile -Command ^
  "$path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount\*\windows.data.notifications.quiethourssettings'; " ^
  "Get-Item -Path $path -ErrorAction SilentlyContinue | Out-Null"

:: Disable "Automatic rules" via the modern Settings backing store
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications" /v ToastEnabled /t REG_DWORD /d 1 /f >nul 2>&1

echo.
echo Done. Please also check manually (this script can't fully
echo automate Windows' newer Settings UI toggles):
echo.
echo   Settings ^> System ^> Focus assist ^> "When these rules are
echo   met, temporarily turn on focus assist" ^> ensure
echo   "When I'm playing a game" is set OFF.
echo.
echo For a guaranteed fix regardless of Windows settings:
echo   In Rust's video options, switch from Fullscreen to
echo   "Fullscreen Windowed" (borderless). This avoids Windows
echo   detecting exclusive fullscreen entirely, which is the
echo   root trigger for notification suppression.
echo.

echo Restart Chrome now for changes to take effect.
echo.
pause
