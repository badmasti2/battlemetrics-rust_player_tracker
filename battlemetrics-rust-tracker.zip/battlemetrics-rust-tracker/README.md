# BattleMetrics Rust Player Tracker

A Tampermonkey userscript that watches specific Rust players on
[BattleMetrics](https://www.battlemetrics.com/servers/rust) and sends you a
desktop notification the moment their status changes — online, offline, or
unknown, in any direction.

Useful for keeping tabs on friends, clan members, or people you'd like a
heads-up about when they log on or off a server.

![status](https://img.shields.io/badge/status-working-brightgreen)
![platform](https://img.shields.io/badge/platform-Tampermonkey-blue)

---

## Features

- 🟢🔴🟠 Tracks any number of named players per server page
- Desktop notifications on **every** status transition (online↔offline↔unknown)
- Reads the server's live "Active Players" table — not the fast-scrolling
  event feed — so it won't silently miss a join/leave on busy servers
- Manual override buttons if you want to mark someone online/offline/unknown
  yourself
- Small on-page panel showing everyone you're tracking at a glance
- A standalone notification-permission tester, so you can quickly tell
  whether a "notifications not working" issue is the script or your browser/OS
- A Windows `.bat` helper for the most common cause of "notifications stopped
  working": fullscreen games suppressing Windows notifications

---

## Requirements

- **Google Chrome** (or any Chromium-based browser — Edge, Brave, etc.)
- **[Tampermonkey](https://www.tampermonkey.net/)** browser extension
- A BattleMetrics account is *not* required — this works on public server pages

---

## Installation

1. **Install Tampermonkey** for your browser, if you don't have it already:
   [tampermonkey.net](https://www.tampermonkey.net/)

2. **Install the userscript:**
   - Click the Tampermonkey icon in your browser toolbar → **Dashboard**
   - Go to the **Utilities** tab (or **+** to create a new script)
   - Open [`scripts/battlemetrics-rust-tracker.user.js`](scripts/battlemetrics-rust-tracker.user.js)
     from this repo, copy its full contents
   - Paste into a new Tampermonkey script and save (Ctrl+S)

3. **Visit any Rust server page on BattleMetrics**, for example:
   `https://www.battlemetrics.com/servers/rust/<server-id>`

   A small panel titled **"Rust Player Tracker"** will appear on the right
   side of the page.

4. **Grant notification permission** when your browser prompts you (usually
   on first load). If you miss the prompt, click the lock/info icon next to
   the address bar → Notifications → **Allow**.

That's it — you're ready to track players.

---

## Usage

1. Type a player's exact in-game name into the **Username** box in the panel.
2. Click **Add** to start tracking them.
3. Their status shows up in the **"Players Currently Tracking"** list:
   - 🟢 Online
   - 🔴 Offline
   - 🟠 Unknown (not yet detected, or manually set)
4. You'll get a desktop notification any time that status changes — including
   manual changes you make yourself with the 🟢/🔴/🟠 buttons.
5. To stop tracking someone, type their name and click **Remove**.

The panel persists across page reloads and revisits — your tracked list and
last-known statuses are saved via Tampermonkey's storage.

---

## Troubleshooting

### I'm not getting any notifications at all

Use the included tester first: install
[`scripts/battlemetrics-notification-test.user.js`](scripts/battlemetrics-notification-test.user.js)
the same way as the main script, then visit a BattleMetrics Rust server page.
A **"🔔 Test Notification"** button will appear — click it. It will tell you
exactly what's failing:

- **Red banner, "permission: denied"** → Notifications are blocked for
  battlemetrics.com in your browser. Go to your browser's site settings
  (`chrome://settings/content/notifications` in Chrome) and set it to Allow.
- **Green banner but no popup appears** → Your browser/OS is suppressing the
  popup even though the site is allowed to send one. See below.
- **Green banner and the popup does appear** → Notifications work fine on
  this site; if the main tracker still isn't notifying you, please
  [open an issue](../../issues) with details.

### Notifications stop while I'm playing Rust (or any fullscreen game)

This is expected Windows/browser behavior, not a script bug. Fullscreen
exclusive apps typically block the OS from rendering notification popups on
top of the game, and Windows' Focus Assist can auto-suppress notifications
whenever it detects a fullscreen app running.

Two ways to fix it:

1. **(Most reliable) Switch Rust to "Fullscreen Windowed" (borderless) mode**
   in Rust's video settings, instead of true Fullscreen. This avoids Windows
   entering exclusive fullscreen mode in the first place, so there's nothing
   to trigger suppression.
2. Run [`scripts/fix-notifications-fullscreen.bat`](scripts/fix-notifications-fullscreen.bat)
   **as Administrator**. This attempts to disable Focus Assist's automatic
   "when I'm playing a game" rule. It also prints manual steps to double
   check in Settings, since Microsoft doesn't expose a fully reliable
   registry key for this on every Windows build.

### The tracker seems stuck / status not updating

- Make sure you're on a Rust server page (`battlemetrics.com/servers/rust/...`),
  not the general server list.
- BattleMetrics occasionally updates their page layout, which can break the
  script's ability to find the Active Players table. If tracking stops
  working entirely after a BattleMetrics update, please
  [open an issue](../../issues).

---

## How it works (technical notes)

- The script polls the page's **Active Players table** every 2 seconds and
  checks whether each tracked name currently appears in it. This is more
  reliable than parsing the scrolling "joined/left the game" event feed,
  which BattleMetrics only keeps a couple dozen entries of — a fast enough
  server can cycle through that entire feed in under a few minutes, causing
  a poll to silently miss short-lived join/leave events.
- Status changes are funneled through a single function that compares new
  vs. last-known status and fires a notification on any real change,
  including changes made manually.
- All data (tracked player list, current status, manual overrides) is stored
  locally via Tampermonkey's `GM_getValue`/`GM_setValue` — nothing is sent
  anywhere else.

---

## Disclaimer

This project is not affiliated with or endorsed by BattleMetrics. It works
by reading publicly visible page content client-side in your own browser;
it does not use any private API or authenticated data.
